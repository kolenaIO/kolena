import dataclasses
import json
from abc import ABC
from abc import abstractmethod
from typing import Any
from typing import Dict
from typing import Iterator
from typing import List
from typing import Optional
from typing import Tuple
from typing import Type
from typing import TypeVar
from typing import Union

import pandas as pd
from pydantic import validate_arguments

from kolena._api.v1.core import Model as API
from kolena._api.v1.detection import Model as DetectionAPI
from kolena._api.v1.workflow import WorkflowType
from kolena._utils import krequests
from kolena._utils import log
from kolena._utils._consts import _BatchSize
from kolena._utils.batched_load import _BatchedLoader
from kolena._utils.batched_load import DFType
from kolena._utils.frozen import Frozen
from kolena._utils.instrumentation import WithTelemetry
from kolena._utils.serde import from_dict
from kolena._utils.validators import ValidatorConfig
from kolena.detection._internal import BaseTestCase
from kolena.detection._internal import BaseTestImage
from kolena.detection._internal import BaseTestSuite
from kolena.detection._internal.test_image import TestImageType
from kolena.errors import InputValidationError
from kolena.errors import RemoteError


InferenceType = TypeVar("InferenceType")
SampleInferences = Tuple[TestImageType, Optional[List[InferenceType]]]


class BaseModel(ABC, Frozen, WithTelemetry):
    """
    The descriptor for your model within the Kolena platform.
    """

    #: Unique name of the model within the platform. If the provided model name has already been registered, that model
    #: and its metadata are loaded upon instantiation.
    name: str

    #: Unstructured metadata associated with the model.
    metadata: Dict[str, Any]

    _id: int
    _workflow: WorkflowType

    _TestImageClass: Type[BaseTestImage] = BaseTestImage
    _TestCaseClass: Type[BaseTestCase] = BaseTestCase
    _TestSuiteClass: Type[BaseTestSuite] = BaseTestSuite
    _InferenceClass: Type[InferenceType] = InferenceType
    _LoadInferencesDataFrameClass: Type[DFType] = DFType

    @validate_arguments(config=ValidatorConfig)
    def __init__(self, name: str, workflow: WorkflowType, metadata: Optional[Dict[str, Any]] = None):
        try:
            loaded = self._load_by_name(name)
            if len(loaded.metadata) > 0 and loaded.metadata != metadata:
                log.warn(f"mismatch in model metadata, using loaded metadata (loaded: {loaded.metadata})")
        except RemoteError:  # TODO: better error
            loaded = self._create(workflow, name, metadata or {})

        self.name = name
        self.metadata = loaded.metadata
        self._id = loaded.id
        self._workflow = WorkflowType(loaded.workflow)
        self._freeze()

    @classmethod
    @validate_arguments(config=ValidatorConfig)
    def _create(cls, workflow: WorkflowType, name: str, metadata: Dict[str, Any]) -> API.EntityData:
        log.info(f"creating new model '{name}'")
        request = API.CreateRequest(name=name, metadata=metadata, workflow=workflow.value)
        res = krequests.post(endpoint_path="/detection/model/create", data=json.dumps(dataclasses.asdict(request)))
        krequests.raise_for_status(res)
        log.success(f"created new model '{name}'")
        return from_dict(data_class=API.EntityData, data=res.json())

    @classmethod
    @validate_arguments(config=ValidatorConfig)
    def _load_by_name(cls, name: str) -> API.EntityData:
        request = API.LoadByNameRequest(name=name)
        res = krequests.put(endpoint_path="/detection/model/load-by-name", data=json.dumps(dataclasses.asdict(request)))
        krequests.raise_for_status(res)
        return from_dict(data_class=API.EntityData, data=res.json())

    @validate_arguments(config=ValidatorConfig)
    def load_inferences(
        self,
        test_object: Union[_TestCaseClass, _TestSuiteClass],
    ) -> List[Tuple[_TestImageClass, Optional[List[_InferenceClass]]]]:
        """Retrieve the uploaded inferences for each image in a test case or test suite."""
        return list(self.iter_inferences(test_object))

    @validate_arguments(config=ValidatorConfig)
    def iter_inferences(
        self,
        test_object: Union[_TestCaseClass, _TestSuiteClass],
    ) -> Iterator[Tuple[_TestImageClass, Optional[List[_InferenceClass]]]]:
        """Iterate through the uploaded inferences for each image in a test case or test suite."""
        for df_batch in self._iter_inference_batch_for_reference(test_object):
            yield from (self._inferences_from_record(record) for record in df_batch.itertuples())

    @validate_arguments(config=ValidatorConfig)
    def _iter_inference_batch_for_reference(
        self,
        test_object: Union[_TestCaseClass, _TestSuiteClass],
        batch_size: int = _BatchSize.LOAD_SAMPLES,
    ) -> Iterator[_LoadInferencesDataFrameClass]:
        if batch_size <= 0:
            raise InputValidationError(f"invalid batch_size '{batch_size}': expected positive integer")
        log.info(f"loading images of model '{self.name}' by batch")
        test_id_key = "test_case_id" if isinstance(test_object, self._TestCaseClass) else "test_suite_id"
        params = dict(model_id=self._id, batch_size=batch_size, **{test_id_key: test_object._id})
        init_request = DetectionAPI.InitLoadInferencesRequest(**params)
        yield from _BatchedLoader.iter_data(
            init_request=init_request,
            endpoint_path=DetectionAPI.Path.INIT_LOAD_INFERENCES,
            df_class=self._LoadInferencesDataFrameClass,
        )
        log.success(f"loaded images of model '{self.name}' by batch")

    @validate_arguments(config=ValidatorConfig)
    def load_inferences_by_test_case(
        self,
        test_suite: _TestSuiteClass,
    ) -> Dict[int, List[SampleInferences[_TestImageClass, _InferenceClass]]]:
        """Retrieve the uploaded inferences of a test suite for each image, grouped by test case."""
        log.info(f"loading inferences for test suite '{test_suite.name}'")
        batches = list(self._iter_inference_batch_for_test_suite(test_suite))
        df_all = pd.concat(batches)
        df = pd.DataFrame(columns=["test_case_id", "test_sample"])
        df["test_case_id"] = df_all["test_case_id"]
        df["test_sample"] = df_all.apply(lambda record: self._inferences_from_record(record), axis=1)
        df_by_testcase = df.groupby("test_case_id")["test_sample"].agg(list).to_dict()
        log.success(f"loaded inferences for test suite '{test_suite.name}'")
        return df_by_testcase

    @validate_arguments(config=ValidatorConfig)
    def _iter_inference_batch_for_test_suite(
        self,
        test_suite: _TestSuiteClass,
        batch_size: int = _BatchSize.LOAD_SAMPLES,
    ) -> Iterator[_LoadInferencesDataFrameClass]:
        if batch_size <= 0:
            raise InputValidationError(f"invalid batch_size '{batch_size}': expected positive integer")
        log.info(f"loading inferences of model '{self.name}' for test suite '{test_suite.name}' by batch")
        params = dict(model_id=self._id, batch_size=batch_size, test_suite_id=test_suite._id)
        init_request = DetectionAPI.InitLoadInferencesByTestCaseRequest(**params)
        yield from _BatchedLoader.iter_data(
            init_request=init_request,
            endpoint_path=DetectionAPI.Path.INIT_LOAD_INFERENCES_BY_TEST_CASE,
            df_class=self._LoadInferencesDataFrameClass,
        )
        log.success(f"loaded inferences of model '{self.name}' for test suite '{test_suite.name}' by batch")

    @abstractmethod
    def _inferences_from_record(self, record: Any) -> Tuple[_TestImageClass, Optional[List[_InferenceClass]]]:
        ...
