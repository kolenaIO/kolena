import dataclasses
import json
from abc import ABC
from abc import abstractmethod
from collections import OrderedDict
from contextlib import contextmanager
from typing import Dict
from typing import Iterator
from typing import List
from typing import Optional

from pydantic import validate_arguments

from kolena._api.v1.core import TestCase as TestCaseAPI
from kolena._api.v1.core import TestSuite as API
from kolena._api.v1.workflow import WorkflowType
from kolena._utils import krequests
from kolena._utils import log
from kolena._utils.frozen import Frozen
from kolena._utils.instrumentation import WithTelemetry
from kolena._utils.serde import from_dict
from kolena._utils.validators import ValidatorConfig
from kolena.detection._internal import BaseTestCase
from kolena.errors import IncorrectUsageError
from kolena.errors import RemoteError


class BaseTestSuite(ABC, Frozen, WithTelemetry):
    """
    A test suite groups together one or more test cases.

    :param name: name of the test suite to create or load
    :param version: optionally specify the version of the test suite to load. When absent, the latest version is loaded.
        Ignored when creating new test suites
    :param description: optionally specify a description for a newly created test suite. For existing test suites, this
        description can be edited via :meth:`TestSuite.edit`
    :param test_cases: optionally specify a list of test cases to populate a new test suite. For existing test suites,
        test cases can be edited via :meth:`TestSuite.edit`
    """

    _id: int
    _workflow: WorkflowType

    @classmethod
    @abstractmethod
    def _test_case_from(cls, response: TestCaseAPI.EntityData) -> BaseTestCase:
        pass

    def __init__(
        self,
        name: str,
        workflow: WorkflowType,
        version: Optional[int] = None,
        description: Optional[str] = None,
        test_cases: Optional[List[BaseTestCase]] = None,
    ):
        try:
            loaded = self._load_by_name(name, version)
            provided_description = description or ""
            if description is not None and loaded.description != provided_description:
                log.warn("provided description does not match stored description, use editor to update")
        except RemoteError:  # TODO: better error
            if version is not None:
                log.warn(f"creating new test suite '{name}', ignoring provided version")
            loaded = self._create(workflow, name, description)

        self.name = loaded.name
        self.version = loaded.version
        self.description = loaded.description
        self.test_cases = [self._test_case_from(tc) for tc in loaded.test_cases]
        self._id = loaded.id
        self._workflow = WorkflowType(loaded.workflow)
        self._freeze()

        if test_cases is not None:
            self._populate(test_cases)

    @classmethod
    @validate_arguments(config=ValidatorConfig)
    def _create(cls, workflow: WorkflowType, name: str, description: Optional[str] = None) -> API.EntityData:
        """Create a new test suite with the provided name."""
        log.info(f"creating new test suite '{name}'")
        request = API.CreateRequest(name=name, description=description or "", workflow=workflow.value)
        data = json.dumps(dataclasses.asdict(request))
        res = krequests.post(endpoint_path="/detection/test-suite/create", data=data)
        krequests.raise_for_status(res)
        log.success(f"created new test suite '{name}'")
        return from_dict(data_class=API.EntityData, data=res.json())

    @classmethod
    @validate_arguments(config=ValidatorConfig)
    def _load_by_name(cls, name: str, version: Optional[int] = None) -> API.EntityData:
        """Retrieve the existing test suite with the provided name."""
        request = API.LoadByNameRequest(name=name, version=version)
        data = json.dumps(dataclasses.asdict(request))
        res = krequests.put(endpoint_path="/detection/test-suite/load-by-name", data=data)
        krequests.raise_for_status(res)
        return from_dict(data_class=API.EntityData, data=res.json())

    @validate_arguments(config=ValidatorConfig)
    def _populate(self, test_cases: List[BaseTestCase]) -> None:
        """Convenience method to populate an empty test suite with the provided test cases. Throws if not empty."""
        if len(self.test_cases) != 0:
            raise IncorrectUsageError(
                "Refusing to add test cases to a test suite that is not empty. Use test_suite.edit() to update.",
            )
        with self.edit() as editor:
            log.info(f"adding test cases to test suite '{self.name}'")
            for test_case in log.progress_bar(test_cases):
                editor.add(test_case)
            log.info(f"added test cases to test suite '{self.name}'")

    class Editor:
        """
        Interface to edit a test suite. Create with :meth:`TestSuite.edit`.
        """

        _workflow: WorkflowType

        def __init__(self) -> None:
            self._description = ""
            self._test_cases: Dict[str, int] = OrderedDict()  # map from name -> id

        @validate_arguments(config=ValidatorConfig)
        def description(self, description: str) -> None:
            """
            Update the description of the test suite.

            :param description: the new description of the test suite
            """
            self._description = description

        @validate_arguments(config=ValidatorConfig)
        def add(self, test_case: BaseTestCase) -> None:
            """
            Add the provided :class:`kolena.detection.TestCase` to the test suite.

            Only one version of a given test case may be present in a given test suite.

            :param test_case: the test case to add to the test suite
            """
            self._assert_workflows_match(test_case)
            name = test_case.name
            if name in self._test_cases.keys():
                raise ValueError(f"test case '{name}' already in suite")
            self._test_cases[name] = test_case._id

        @validate_arguments(config=ValidatorConfig)
        def remove(self, test_case: BaseTestCase) -> None:
            """
            Remove the provided :class:`kolena.detection.TestCase` from the test suite. Any version of this test
            case in this test suite will be removed; the version does not need to match exactly.

            :param test_case: the test case to be removed from the test suite
            """
            name = test_case.name
            if name not in self._test_cases.keys():
                raise KeyError(f"test case '{name}' not in suite")
            self._test_cases.pop(name)

        @validate_arguments(config=ValidatorConfig)
        def merge(self, test_case: BaseTestCase) -> None:
            """
            Add the provided :class:`kolena.detection.TestCase` to the test suite, replacing any previous version
            of the test case that may be present in the suite.

            :param test_case: the test case to be merged into the test suite
            """
            self._assert_workflows_match(test_case)
            self._test_cases[test_case.name] = test_case._id

        def _assert_workflows_match(self, test_case: BaseTestCase) -> None:
            if test_case._workflow != self._workflow:
                raise ValueError(
                    f"test case workflow '{test_case._workflow}' mismatches test suite workflow '{self._workflow}'",
                )

    @contextmanager
    def edit(self) -> Iterator[Editor]:
        """
        Edit the test suite in a context. Changes are committed and the version of the test suite is incremented only
        when the context is exited.
        """
        editor = BaseTestSuite.Editor()
        editor._workflow = self._workflow  # set outside of init such that parameter does not leak into documentation
        editor.description(self.description)
        for test_case in self.test_cases:
            editor.add(test_case)

        yield editor

        # no-op contexts have no effect, do not bump version
        test_cases_equal = {tc._id for tc in self.test_cases} == set(editor._test_cases.values())
        if editor._description == self.description and test_cases_equal:
            return
        log.info(f"updating test suite '{self.name}'")
        request = API.EditRequest(
            test_suite_id=self._id,
            current_version=self.version,
            name=self.name,
            description=editor._description,
            test_case_ids=list(editor._test_cases.values()),
        )
        data = json.dumps(dataclasses.asdict(request))
        res = krequests.post(endpoint_path="/detection/test-suite/edit", data=data)
        krequests.raise_for_status(res)
        log.success(f"updated test suite '{self.name}'")
        test_suite_data = from_dict(data_class=API.EntityData, data=res.json())
        with self._unfrozen():
            self.version = test_suite_data.version
            self.description = test_suite_data.description
            self.test_cases = [self._test_case_from(tc) for tc in test_suite_data.test_cases]
            self._id = test_suite_data.id
