import dataclasses
import json
from abc import ABC
from collections import OrderedDict
from contextlib import contextmanager
from typing import Dict
from typing import Iterator
from typing import List
from typing import Optional
from typing import Type

import pandas as pd
from pydantic import validate_arguments

from kolena._api.v1.core import TestCase as API
from kolena._api.v1.workflow import WorkflowType
from kolena._utils import krequests
from kolena._utils import log
from kolena._utils._consts import _BatchSize
from kolena._utils.batched_load import _BatchedLoader
from kolena._utils.batched_load import DFType
from kolena._utils.batched_load import init_upload
from kolena._utils.batched_load import upload_data_frame
from kolena._utils.dataframes.validators import validate_df_schema
from kolena._utils.frozen import Frozen
from kolena._utils.instrumentation import WithTelemetry
from kolena._utils.serde import from_dict
from kolena._utils.validators import ValidatorConfig
from kolena.detection._internal import BaseTestImage
from kolena.errors import IncorrectUsageError
from kolena.errors import RemoteError


class BaseTestCase(ABC, Frozen, WithTelemetry):
    """
    A test case holds a set of images to compute performance metrics against.

    :param name: name of the test case to create or load
    :param version: optionally specify the version of the test case to load. When absent, the latest version is loaded.
        Ignored when creating new test cases
    :param description: optionally specify a description for a newly created test case. For existing test cases, this
        description can be edited via :meth:`kolena.detection.TestCase.edit`
    :param images: optionally provide a list of images and associated ground truths to populate a new test case. For
        existing test cases, images can be edited via :meth:`TestCase.edit`.
    """

    _TestImageClass: Type[BaseTestImage] = BaseTestImage
    _TestImageDataFrameClass: Type[DFType] = DFType

    #: The unique name of this test case. Cannot be changed after creation.
    name: str

    #: The version of this test case. A test case's version is automatically incremented whenever it is edited via
    #: :meth:`TestCase.edit`.
    version: int

    #: Free-form, human-readable description of this test case. Can be edited at any time via :meth:`TestCase.edit`.
    description: str

    _id: int
    _workflow: WorkflowType

    def __init__(
        self,
        name: str,
        workflow: WorkflowType,
        version: Optional[int] = None,
        description: Optional[str] = None,
        images: Optional[List[_TestImageClass]] = None,
    ):
        try:
            loaded = self._load_by_name(name, version)
            provided_description = description or ""
            if description is not None and loaded.description != provided_description:
                log.warn("provided description does not match stored description, use editor to update")
        except RemoteError:  # TODO: better error when test case doesn't exist?
            if version is not None:
                log.warn(f"creating new test case '{name}', ignoring provided version")
            loaded = self._create(workflow, name, description)

        self.name = loaded.name
        self.version = loaded.version
        self.description = loaded.description
        self._id = loaded.id
        self._workflow = WorkflowType(loaded.workflow)
        self._freeze()

        if images is not None:
            self._populate(images)

    @classmethod
    def _from(cls, response: API.EntityData) -> "BaseTestCase":
        obj = cls.__new__(cls)
        obj.name = response.name
        obj.version = response.version
        obj.description = response.description
        obj._id = response.id
        obj._workflow = WorkflowType(response.workflow)
        obj._freeze()
        return obj

    @classmethod
    @validate_arguments(config=ValidatorConfig)
    def _create(cls, workflow: WorkflowType, name: str, description: Optional[str] = None) -> API.EntityData:
        """Create a new test case with the provided name."""
        log.info(f"creating new test case '{name}'")
        request = API.CreateRequest(name=name, description=description or "", workflow=workflow.value)
        res = krequests.post(endpoint_path="/detection/test-case/create", data=json.dumps(dataclasses.asdict(request)))
        krequests.raise_for_status(res)
        log.success(f"created new test case '{name}'")
        return from_dict(data_class=API.EntityData, data=res.json())

    @classmethod
    @validate_arguments(config=ValidatorConfig)
    def _load_by_name(cls, name: str, version: Optional[int] = None) -> API.EntityData:
        """Load an existing test case with the provided name."""
        request = API.LoadByNameRequest(name=name, version=version)
        res = krequests.put(
            endpoint_path="/detection/test-case/load-by-name",
            data=json.dumps(dataclasses.asdict(request)),
        )
        krequests.raise_for_status(res)
        return from_dict(data_class=API.EntityData, data=res.json())

    @validate_arguments(config=ValidatorConfig)
    def _populate(self, images: List[_TestImageClass]) -> None:
        if self.version != 0:
            raise IncorrectUsageError(
                "refusing to populate a test case that has already been edited, use test_case.edit() to update",
            )
        with self.edit() as editor:
            log.info(f"adding images to test case '{self.name}'")
            for image in log.progress_bar(images):
                editor.add(image)
            log.success(f"added images to test case '{self.name}'")

    @validate_arguments(config=ValidatorConfig)
    def load_images(self) -> List[_TestImageClass]:
        """Load all test images with their associated ground truths in this test case."""
        return list(self.iter_images())

    @validate_arguments(config=ValidatorConfig)
    def iter_images(self) -> Iterator[_TestImageClass]:
        """Iterate through all images with their associated ground truths in this test case."""
        log.info(f"loading test images for test case '{self.name}' by batch")
        init_request = API.InitLoadContentsRequest(batch_size=_BatchSize.LOAD_SAMPLES, test_case_id=self._id)
        for df in _BatchedLoader.iter_data(
            init_request=init_request,
            endpoint_path="/detection/test-case/load-images/init",
            df_class=self._TestImageDataFrameClass,
        ):
            for record in df.itertuples():
                yield self._TestImageClass._from_record(record)
        log.success(f"loaded test images for test case '{self.name}' by batch")

    class Editor:
        """
        Interface to edit a test case. Create with :meth:`TestCase.edit`.
        """

        def __init__(self) -> None:
            self._edited = False
            self._description = ""
            self._images: Dict[str, BaseTestImage] = OrderedDict()

        @validate_arguments(config=ValidatorConfig)
        def description(self, description: str) -> None:
            """
            Update the description of this test case.

            :param description: the new test case description
            """
            self._edited = True
            self._description = description

        @validate_arguments(config=ValidatorConfig)
        def add(self, image: BaseTestImage) -> None:
            """
            Add a test image to the test case, targeting the ``ground_truths`` held by the image.

            To filter the ground truths associated with a test image, see :meth:`kolena.detection.TestImage.filter`.

            :param image: the test image to add to the test case, holding corresponding ground truths
            :raises ValueError: if the image already exists in the test case
            """
            if image.locator in self._images.keys():
                raise ValueError(f"duplicate image: '{image.locator}' already in test case")
            self._images[image.locator] = image
            self._edited = True

        @validate_arguments(config=ValidatorConfig)
        def remove(self, image: BaseTestImage) -> None:
            """
            Remove the image from the test case.

            :param image: the test image to remove
            :raises KeyError: if the image is not in the test case
            """
            if image.locator not in self._images.keys():
                raise KeyError(f"unrecognized image: '{image.locator}' not in test case")
            self._edited = True
            self._images.pop(image.locator)

    @classmethod
    def _to_data_frame(cls, images: List[_TestImageClass]) -> _TestImageDataFrameClass:
        records = [cls._TestImageClass._to_record(image) for image in images]
        columns = cls._TestImageClass._meta_keys()
        df = pd.DataFrame(records, columns=columns)
        return cls._TestImageDataFrameClass(
            validate_df_schema(df, cls._TestImageDataFrameClass.get_schema(), trusted=True),
        )

    @contextmanager
    def edit(self) -> Iterator[Editor]:
        """
        Edit this test case in a context:

        .. code-block:: python

            with test_case.edit() as editor:
                # perform as many editing actions as desired
                editor.add(...)
                editor.remove(...)

        Changes are committed to the Kolena platform when the context is exited.
        """
        editor = BaseTestCase.Editor()
        editor.description(self.description)
        for image in self.iter_images():
            editor.add(image)
        editor._edited = False

        yield editor

        # no-op contexts have no effect, do not bump version
        if not editor._edited:
            return

        log.info(f"updating test case '{self.name}'")
        init_response = init_upload()
        df = self._to_data_frame(list(editor._images.values()))
        df_serialized = df.as_serializable()

        upload_data_frame(df=df_serialized, batch_size=_BatchSize.UPLOAD_RECORDS, load_uuid=init_response.uuid)
        request = API.CompleteEditRequest(
            test_case_id=self._id,
            current_version=self.version,
            description=editor._description,
            uuid=init_response.uuid,
        )
        complete_res = krequests.put(
            endpoint_path="/detection/test-case/edit/complete",
            data=json.dumps(dataclasses.asdict(request)),
        )
        krequests.raise_for_status(complete_res)
        log.success(f"updated test case '{self.name}'")
        test_case_data = from_dict(data_class=API.EntityData, data=complete_res.json())
        with self._unfrozen():
            self.version = test_case_data.version
            self.description = test_case_data.description
            self._id = test_case_data.id
