from enum import Enum


class SampleType(str, Enum):
    LOCATOR = "LOCATOR"
    LOCATOR_TEXT = "LOCATOR_TEXT"
