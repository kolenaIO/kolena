from pydantic.dataclasses import dataclass


class BatchedLoad:
    @dataclass(frozen=True)
    class WithLoadUUID:
        uuid: str

    @dataclass(frozen=True)
    class SignedURL:
        signed_url: str

    @dataclass(frozen=True)
    class BaseInitDownloadRequest:
        batch_size: int

    @dataclass(frozen=True)
    class InitDownloadPartialResponse(WithLoadUUID):
        path: str

    @dataclass(frozen=True)
    class CompleteDownloadRequest(WithLoadUUID):
        ...

    @dataclass(frozen=True)
    class InitiateUploadResponse(WithLoadUUID):
        ...
