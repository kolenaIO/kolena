from pydantic.dataclasses import dataclass


class ClientLog:
    @dataclass(frozen=True)
    class UploadLogRequest:
        client_version: str
        timestamp: str
        message: str
        status: str
