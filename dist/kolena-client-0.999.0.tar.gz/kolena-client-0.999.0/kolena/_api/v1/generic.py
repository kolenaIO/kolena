from enum import Enum
from typing import Any
from typing import Dict
from typing import List
from typing import Optional

from pydantic.dataclasses import dataclass

from kolena._api.v1.batched_load import BatchedLoad


class Model:
    class Path(str, Enum):
        LOAD_INFERENCES = "/generic/model/load-inferences"

    @dataclass(frozen=True)
    class LoadInferencesRequest(BatchedLoad.BaseInitDownloadRequest):
        model_id: int
        test_case_id: int


class TestRun:
    class Path(str, Enum):
        CREATE_OR_RETRIEVE = "/generic/test-run/create-or-retrieve"
        MARK_CRASHED = "/generic/test-run/mark-crashed"
        EVALUATE = "/generic/test-run/evaluate"
        LOAD_TEST_SAMPLES = "/generic/test-run/load-remaining-test-samples"
        UPLOAD_INFERENCES = "/generic/test-run/upload-inferences"
        UPLOAD_TEST_SAMPLE_METRICS = "/generic/test-run/upload-test-sample-metrics"
        UPLOAD_TEST_CASE_METRICS = "/generic/test-run/upload-test-case-metrics"
        UPLOAD_TEST_CASE_PLOTS = "/generic/test-run/upload-test-case-plots"
        UPLOAD_TEST_SUITE_METRICS = "/generic/test-run/upload-test-suite-metrics"

    @dataclass(frozen=True)
    class EvaluatorConfiguration:
        display_name: str
        configuration: Dict[str, Any]  # TODO(gh): real type is JSON

    @dataclass(frozen=True)
    class CreateOrRetrieveRequest:
        model_id: int
        test_suite_id: int
        evaluator: Optional[str] = None
        configurations: Optional[List["TestRun.EvaluatorConfiguration"]] = None

    @dataclass(frozen=True)
    class CreateOrRetrieveResponse:
        test_run_id: int

    @dataclass(frozen=True)
    class EvaluateRequest:
        test_run_id: int

    EvaluateResponse = CreateOrRetrieveResponse

    @dataclass(frozen=True)
    class LoadRemainingTestSamplesRequest(BatchedLoad.BaseInitDownloadRequest):
        test_run_id: int

    @dataclass(frozen=True)
    class UploadInferencesRequest(BatchedLoad.WithLoadUUID):
        test_run_id: int

    @dataclass(frozen=True)
    class UploadTestSampleMetricsRequest(BatchedLoad.WithLoadUUID):
        test_run_id: int
        test_case_id: int
        configuration: Optional["TestRun.EvaluatorConfiguration"]

    @dataclass(frozen=True)
    class UploadAggregateMetricsRequest(BatchedLoad.WithLoadUUID):
        test_run_id: int
        test_suite_id: int

    @dataclass(frozen=True)
    class BulkUploadResponse:
        n_uploaded: int


TestRun.CreateOrRetrieveRequest.__pydantic_model__.update_forward_refs()  # type: ignore
TestRun.UploadTestSampleMetricsRequest.__pydantic_model__.update_forward_refs()  # type: ignore
