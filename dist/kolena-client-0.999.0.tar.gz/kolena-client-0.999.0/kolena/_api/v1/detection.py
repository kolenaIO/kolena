from enum import Enum
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Union

from pydantic.dataclasses import dataclass

from kolena._api.v1.batched_load import BatchedLoad


class TestImage:
    class Path(str, Enum):
        INIT_LOAD_IMAGES = "/detection/test-sample/load-images/init"

    @dataclass(frozen=True)
    class LoadImagesRequest:
        dataset: Optional[str] = None

    @dataclass(frozen=True)
    class InitLoadImagesRequest(LoadImagesRequest, BatchedLoad.BaseInitDownloadRequest):
        ...


class Model:
    class Path(str, Enum):
        INIT_LOAD_INFERENCES = "/detection/model/load-inferences/init"
        INIT_LOAD_INFERENCES_BY_TEST_CASE = "/detection/model/load-test-suite-test-cases-inferences/init"

    @dataclass(frozen=True)
    class LoadInferencesRequest:
        model_id: int
        batch_size: int
        test_case_id: Optional[int] = None
        test_suite_id: Optional[int] = None

        def __post_init__(self) -> None:
            if (self.test_case_id is None) == (self.test_suite_id is None):
                raise ValueError("must specify exactly one test case or test suite ID")

    @dataclass(frozen=True)
    class InitLoadInferencesRequest(LoadInferencesRequest, BatchedLoad.BaseInitDownloadRequest):
        ...

    @dataclass(frozen=True)
    class LoadInferencesByTestCaseRequest:
        model_id: int
        batch_size: int
        test_suite_id: int

    @dataclass(frozen=True)
    class InitLoadInferencesByTestCaseRequest(
        LoadInferencesByTestCaseRequest,
        BatchedLoad.BaseInitDownloadRequest,
    ):
        ...


CustomMetricValue = Union[float, int, None]
CustomMetrics = Dict[str, CustomMetricValue]


class TestRun:
    class Path(str, Enum):
        CREATE_OR_RETRIEVE = "/detection/test-run/create-or-retrieve"
        MARK_CRASHED = "/detection/test-run/mark-crashed"
        INIT_LOAD_REMAINING_IMAGES = "/detection/test-run/load-remaining-images/init"
        UPLOAD_IMAGE_RESULTS = "/detection/test-run/upload-inferences/complete"
        UPLOAD_CUSTOM_METRICS = "/detection/test-run/custom-metrics"

    @dataclass(frozen=True)
    class CreateOrRetrieveRequest:
        model_id: int
        test_suite_ids: List[int]
        config: Optional["Metrics.RunConfig"] = None

    @dataclass(frozen=True)
    class CreateOrRetrieveResponse:
        test_run_id: int

    @dataclass(frozen=True)
    class LoadRemainingImagesRequest:
        test_run_id: int
        batch_size: int

    @dataclass(frozen=True)
    class InitLoadRemainingImagesRequest(LoadRemainingImagesRequest, BatchedLoad.BaseInitDownloadRequest):
        ...

    @dataclass(frozen=True)
    class UploadImageResultsRequest(BatchedLoad.WithLoadUUID):
        test_run_id: int

    @dataclass(frozen=True)
    class UploadImageResultsResponse:
        n_uploaded: int

    @dataclass(frozen=True)
    class UpdateCustomMetricsRequest:
        model_id: int
        metrics: Dict[int, Dict[int, CustomMetrics]]  # testsuite_id -> testcase_id -> CustomMetrics


class RunStrategy(str, Enum):
    F1_OPTIMAL = "F1_OPTIMAL"
    ACCURACY_OPTIMAL = "ACCURACY_OPTIMAL"
    FIXED_GLOBAL_THRESHOLD = "FIXED_GLOBAL_THRESHOLD"


class Metrics:
    @dataclass  # remove frozen to make it jsonpickle to be able to do deserialize for metrics computation
    class RunConfig:
        strategy: RunStrategy
        iou_threshold: float
        params: Optional[Dict[str, Any]] = None

    @dataclass(frozen=True)
    class ComputeRequest:
        test_run_id: int
        workflow_type: str
        config: Optional[List["Metrics.RunConfig"]]


# allow referencing e.g. Metrics.RunConfig as type from Metrics.ComputeRequest
Metrics.ComputeRequest.__pydantic_model__.update_forward_refs()  # type: ignore
TestRun.CreateOrRetrieveRequest.__pydantic_model__.update_forward_refs()  # type: ignore
