from typing import Any
from typing import Dict
from typing import List
from typing import Optional

from pydantic.dataclasses import dataclass

from kolena._api.v1.batched_load import BatchedLoad


class TestImages:
    @dataclass(frozen=True)
    class LoadRequest:
        include_augmented: bool
        data_source: Optional[str] = None

    @dataclass(frozen=True)
    class InitDownloadRequest(LoadRequest, BatchedLoad.BaseInitDownloadRequest):
        ...

    @dataclass(frozen=True)
    class RegisterResponse:
        n_images_inserted: int
        n_images_updated: int
        n_tags_inserted: int
        n_tags_updated: int


class TestCase:
    @dataclass(frozen=True)
    class CreateRequest:
        name: str
        description: str

    @dataclass(frozen=True)
    class LoadByNameRequest:
        name: str
        version: Optional[int] = None

    @dataclass(frozen=True)
    class LoadDataRequest:
        test_case_id: int

    @dataclass(frozen=True)
    class InitDownloadDataRequest(LoadDataRequest, BatchedLoad.BaseInitDownloadRequest):
        ...

    @dataclass(frozen=True)
    class EditRequest:
        test_case_id: int
        current_version: int
        name: str  # TODO: deprecate and remove (unused)
        description: str

    @dataclass(frozen=True)
    class CompleteEditRequest(EditRequest, BatchedLoad.WithLoadUUID):
        ...


class TestSuite:
    @dataclass(frozen=True)
    class CreateRequest:
        name: str
        description: str

    @dataclass(frozen=True)
    class LoadByNameRequest:
        name: str
        version: Optional[int] = None

    @dataclass(frozen=True)
    class EditRequest:
        test_suite_id: int
        current_version: int
        name: str
        description: str
        baseline_test_case_ids: List[int]
        non_baseline_test_case_ids: List[int]


class Model:
    @dataclass(frozen=True)
    class LoadByNameRequest:
        name: str

    @dataclass(frozen=True)
    class CreateRequest:
        name: str
        metadata: Dict[str, Any]

    @dataclass(frozen=True)
    class LoadPairResultsRequest:
        model_id: int
        # exactly one of the two must be present
        test_suite_id: Optional[int] = None
        test_case_id: Optional[int] = None

        def __post_init_post_parse__(self) -> None:
            if self.test_suite_id is None and self.test_case_id is None:
                raise ValueError("either test_case_id or test_suite_id must be present")
            if self.test_suite_id is not None and self.test_case_id is not None:
                raise ValueError("only one of test_case_id or test_suite_id may be present")

    @dataclass(frozen=True)
    class InitDownloadPairResultsRequest(LoadPairResultsRequest, BatchedLoad.BaseInitDownloadRequest):
        ...


class TestRun:
    @dataclass(frozen=True)
    class CreateOrRetrieveRequest:
        model_id: int
        test_suite_ids: List[int]

    @dataclass(frozen=True)
    class MarkCrashedRequest:
        test_run_id: int

    @dataclass(frozen=True)
    class LoadRemainingImagesRequest:
        test_run_id: int
        batch_size: int

    @dataclass(frozen=True)
    class InitLoadRemainingImagesRequest(LoadRemainingImagesRequest, BatchedLoad.BaseInitDownloadRequest):
        ...

    @dataclass(frozen=True)
    class UploadImageResultsRequest(BatchedLoad.WithLoadUUID):
        test_run_id: int

    @dataclass(frozen=True)
    class UploadImageResultsResponse:
        n_uploaded: int

    @dataclass(frozen=True)
    class LoadRemainingPairsRequest:
        test_run_id: int
        batch_size: int

    @dataclass(frozen=True)
    class InitLoadRemainingPairsRequest(LoadRemainingPairsRequest, BatchedLoad.BaseInitDownloadRequest):
        ...

    @dataclass(frozen=True)
    class InitLoadRemainingPairsPartialResponse:
        pairs: BatchedLoad.InitDownloadPartialResponse
        embeddings: BatchedLoad.InitDownloadPartialResponse

    @dataclass(frozen=True)
    class UploadPairResultsRequest(BatchedLoad.WithLoadUUID):
        test_run_id: int

    @dataclass(frozen=True)
    class UploadPairResultsResponse:
        n_uploaded: int


class AssetPath:
    @dataclass(frozen=True)
    class Config:
        bucket: str
        prefix: str


class Assets:
    @dataclass(frozen=True)
    class BulkUploadResponse:
        n_uploaded: int
