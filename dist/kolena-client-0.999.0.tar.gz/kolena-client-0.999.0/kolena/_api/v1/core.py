from typing import Any
from typing import Dict
from typing import List
from typing import Optional

from pydantic.dataclasses import dataclass

from kolena._api.v1.batched_load import BatchedLoad


class Model:
    @dataclass(frozen=True)
    class CreateRequest:
        name: str
        metadata: Dict[str, Any]
        workflow: str

    @dataclass(frozen=True)
    class LoadByNameRequest:
        name: str

    @dataclass(frozen=True)
    class EntityData:
        id: int
        name: str
        metadata: Dict[str, Any]
        workflow: str


class TestCase:
    @dataclass(frozen=True)
    class CreateRequest:
        name: str
        description: str
        workflow: str

    @dataclass(frozen=True)
    class CreateFromExistingRequest(BatchedLoad.WithLoadUUID):
        test_case_name: str
        test_suite_name: str
        workflow: str
        compute_metrics_where_possible: bool = False

    @dataclass(frozen=True)
    class CreateFromExistingResponse:
        test_case_id: int
        test_suite_id: int

    @dataclass(frozen=True)
    class LoadByNameRequest:
        name: str
        version: Optional[int] = None

    @dataclass(frozen=True)
    class EntityData:
        id: int
        name: str
        version: int
        description: str
        workflow: str

    @dataclass(frozen=True)
    class LoadContentsRequest:
        test_case_id: int

    @dataclass(frozen=True)
    class InitLoadContentsRequest(LoadContentsRequest, BatchedLoad.BaseInitDownloadRequest):
        ...

    @dataclass(frozen=True)
    class EditRequest:
        test_case_id: int
        current_version: int
        description: str
        reset: bool = False

    @dataclass(frozen=True)
    class CompleteEditRequest(EditRequest, BatchedLoad.WithLoadUUID):
        ...


class TestSuite:
    @dataclass(frozen=True)
    class CreateRequest:
        name: str
        description: str
        workflow: str

    @dataclass(frozen=True)
    class LoadByNameRequest:
        name: str
        version: Optional[int] = None

    @dataclass(frozen=True)
    class EntityData:
        id: int
        name: str
        version: int
        description: str
        test_cases: List[TestCase.EntityData]
        workflow: str

    @dataclass(frozen=True)
    class EditRequest:
        test_suite_id: int
        current_version: int
        name: str
        description: str
        test_case_ids: List[int]


class TestRun:
    @dataclass(frozen=True)
    class MarkCrashedRequest:
        test_run_id: int
