import functools
import os
from typing import Any
from typing import Callable
from typing import Dict
from typing import Optional

from kolena.errors import InvalidClientStateError
from kolena.errors import UninitializedError


class _ClientState:
    def __init__(
        self,
        base_url: Optional[str] = "https://gateway.kolena.cloud",
        api_token: Optional[str] = None,
        jwt_token: Optional[str] = None,
        verbose: bool = False,
        telemetry: bool = False,
        proxies: Optional[Dict[str, str]] = None,
    ):
        self.base_url: Optional[str] = None
        self.api_token: Optional[str] = None
        self.jwt_token: Optional[str] = None
        self.verbose: bool = False
        self.telemetry: bool = False
        self.proxies: Dict[str, str] = {}
        self.update(
            base_url=base_url,
            api_token=api_token,
            jwt_token=jwt_token,
            verbose=verbose,
            telemetry=telemetry,
            proxies=proxies,
        )

    def update(
        self,
        base_url: Optional[str] = None,
        api_token: Optional[str] = None,
        jwt_token: Optional[str] = None,
        verbose: bool = False,
        telemetry: bool = False,
        proxies: Optional[Dict[str, str]] = None,
    ) -> None:
        self.base_url = base_url or self.base_url
        self.api_token = api_token or self.api_token
        self.jwt_token = jwt_token or self.jwt_token
        self.verbose = verbose
        self.telemetry = telemetry
        self.proxies = proxies or {}

    def assert_initialized(self) -> None:
        if self.base_url is None:
            raise InvalidClientStateError("missing base_url")
        if self.jwt_token is None:
            raise UninitializedError("client has not been initialized via kolena.initialize(...)")
        if self.api_token is None:
            raise InvalidClientStateError("missing client api_token")

    def reset(self) -> None:
        # note that base_url remains set
        self.api_token = None
        self.jwt_token = None
        self.verbose = False
        self.telemetry = False


_client_base_url = os.environ.get("KOLENA_CLIENT_BASE_URL", "https://gateway.kolena.cloud")
_client_state = _ClientState(base_url=_client_base_url)


def kolena_initialized(func: Callable) -> Callable:
    """Raises InvalidKolenaStateError if not initialized"""

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        _client_state.assert_initialized()
        return func(*args, **kwargs)

    return wrapper
