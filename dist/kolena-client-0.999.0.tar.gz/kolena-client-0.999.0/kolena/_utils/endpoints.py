from kolena._utils.state import _client_state
from kolena.errors import InvalidClientStateError


API_VERSION = "v1"


def get_endpoint(endpoint_path: str) -> str:
    if _client_state.base_url is None:
        raise InvalidClientStateError("missing base_url")
    return f"{_client_state.base_url}/{API_VERSION}/{endpoint_path.lstrip('/')}"
