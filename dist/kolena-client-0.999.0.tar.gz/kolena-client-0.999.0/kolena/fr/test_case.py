import dataclasses
import json
from collections import OrderedDict
from contextlib import contextmanager
from typing import Dict
from typing import Iterator
from typing import Optional

import pandas as pd
from pydantic import validate_arguments
from pydantic.dataclasses import dataclass

from kolena._api.v1.fr import TestCase as API
from kolena._utils import krequests
from kolena._utils import log
from kolena._utils.batched_load import _BatchedLoader
from kolena._utils.batched_load import init_upload
from kolena._utils.batched_load import upload_data_frame
from kolena._utils.dataframes.validators import validate_df_schema
from kolena._utils.serde import from_dict
from kolena._utils.uninstantiable import Uninstantiable
from kolena._utils.validators import ValidatorConfig
from kolena.fr._consts import _BatchSize
from kolena.fr.datatypes import TEST_CASE_COLUMNS
from kolena.fr.datatypes import TestCaseDataFrame
from kolena.fr.datatypes import TestCaseDataFrameSchema
from kolena.fr.datatypes import TestCaseRecord


class TestCase(Uninstantiable["TestCase.Data"]):
    """
    A group of test samples that can be added to a :class:`kolena.fr.TestSuite`.

    The test case is the base unit of results computation in the Kolena platform. Metrics are computed by test case.
    """

    @dataclass(frozen=True, config=ValidatorConfig)
    class Data:
        id: int
        name: str
        version: int
        description: str
        image_count: int
        pair_count_genuine: int
        pair_count_imposter: int

    @classmethod
    def create(cls, name: str, description: Optional[str] = None) -> "TestCase":
        """
        Create a new test case with the provided name.

        :param name: unique name for the test case. Cannot be changed after creation
        :param description: optionally specify a freeform description for this test case. May be changed at any time
            after creation using a :class:`TestCase.Editor`
        :return: the created test case, empty and at version 0
        """
        log.info(f"creating new test case '{name}'")
        request = API.CreateRequest(name=name, description=description or "")
        res = krequests.post(endpoint_path="/fr/test-case/create", data=json.dumps(dataclasses.asdict(request)))
        krequests.raise_for_status(res)
        log.success(f"created new test case '{name}'")
        return TestCase.__factory__(from_dict(data_class=TestCase.Data, data=res.json()))

    @classmethod
    def load_by_name(cls, name: str, version: Optional[int] = None) -> "TestCase":
        """
        Load an existing test case with the provided name.

        :param name: the name of the test case to load
        :param version: optionally specify the target version of the test case to load. When absent, the highest version
            of the test case with the provided name is returned
        :return: the loaded test case
        """
        log.info(f"loading test case '{name}'")
        request = API.LoadByNameRequest(name=name, version=version)
        res = krequests.put(endpoint_path="/fr/test-case/load-by-name", data=json.dumps(dataclasses.asdict(request)))
        krequests.raise_for_status(res)
        log.success(f"loaded test case '{name}'")
        return TestCase.__factory__(from_dict(data_class=TestCase.Data, data=res.json()))

    def load_data(self) -> TestCaseDataFrame:
        """
        Load all pairs data for a test case.

        :return: a DataFrame containing all pairs defined in this test case
        """
        return _BatchedLoader.concat(self.iter_data(), TestCaseDataFrame)

    @dataclass(config=ValidatorConfig)
    class _Editor:
        edited: bool
        description: str
        samples: Dict[str, TestCaseRecord]

    class Editor(Uninstantiable[_Editor]):
        @validate_arguments
        def description(self, description: str) -> None:
            """
            Update the description of this test case.

            :param description: the new test case description
            """
            self.data.edited = True
            self.data.description = description

        @validate_arguments
        def add(self, locator_a: str, locator_b: str, is_same: bool) -> None:
            """
            Add the provided image pair to the test case.

            Note that if the image pair with ``locator_a`` and ``locator_b`` is already defined within the platform,
            the value for ``is_same`` must match the value already defined.

            :param locator_a: the left locator for the image pair
            :param locator_b: the right locator for the image pair
            :param is_same: whether or not these images should be considered a true pair or an imposter pair
            :raises ValueError: the image pair already exists in the test case
            """
            key = self._key(locator_a, locator_b)
            if key in self.data.samples.keys():
                raise ValueError(f"duplicate record: {locator_a}, {locator_b} already exists in this test case")
            self.data.edited = True
            self.data.samples[key] = (locator_a, locator_b, is_same)

        @validate_arguments
        def remove(self, locator_a: str, locator_b: str) -> None:
            """
            Remove the provided pair from the test case.

            :param locator_a: the left locator for the image pair
            :param locator_b: the right locator for the image pair
            :raises KeyError: if the provided locator pair is not in the test case
            """
            key = self._key(locator_a, locator_b)
            if key not in self.data.samples.keys():
                raise KeyError(f"pair not in test case: {locator_a}, {locator_b}")
            self.data.edited = True
            self.data.samples.pop(key)

        @staticmethod
        def _key(locator_a: str, locator_b: str) -> str:
            # newline is guaranteed to not be present in the locators
            return f"{locator_a}\n{locator_b}"

    @contextmanager
    def edit(self) -> Iterator[Editor]:
        """
        Edit this test case in a context:

        .. code-block:: python

            with test_case.edit() as editor:
                # perform as many editing actions as desired
                editor.add(...)
                editor.remove(...)

        The changes are committed to the Kolena platform when the context is exited.
        """
        editor = TestCase.Editor.__factory__(
            TestCase._Editor(edited=False, description=self.data.description, samples=OrderedDict()),
        )
        df_existing = self.load_data()
        for record in df_existing.itertuples():
            editor.add(record.locator_a, record.locator_b, record.is_same)
        editor.data.edited = False

        yield editor

        # no-op contexts have no effect, do not bump version
        if not editor.data.edited:
            return

        log.info(f"updating test case '{self.data.name}'")
        init_response = init_upload()
        df = pd.DataFrame(editor.data.samples.values(), columns=TEST_CASE_COLUMNS)
        df_validated = validate_df_schema(df, TestCaseDataFrameSchema)

        upload_data_frame(df=df_validated, batch_size=_BatchSize.UPLOAD_RECORDS, load_uuid=init_response.uuid)
        request = API.CompleteEditRequest(
            test_case_id=self.data.id,
            current_version=self.data.version,
            name=self.data.name,
            description=editor.data.description,
            uuid=init_response.uuid,
        )
        complete_res = krequests.post(
            endpoint_path="/fr/test-case/edit/complete",
            data=json.dumps(dataclasses.asdict(request)),
        )
        krequests.raise_for_status(complete_res)
        test_case_data = from_dict(data_class=TestCase.Data, data=complete_res.json())
        log.success(f"updated test case '{self.data.name}'")
        self.__update__(test_case_data)

    @validate_arguments
    def iter_data(self, batch_size: int = 10_000_000) -> Iterator[TestCaseDataFrame]:
        """
        Iterator of DataFrames describing all pairs data for a test case.

        :param batch_size: optionally specify maximum number of rows to be returned in a single DataFrame. By default,
            limits row count to 10_000_000.
        """
        log.info(f"loading image pairs in test case '{self.data.name}' by batch")
        init_request = API.InitDownloadDataRequest(batch_size=batch_size, test_case_id=self.data.id)
        yield from _BatchedLoader.iter_data(
            init_request=init_request,
            endpoint_path="/fr/test-case/load-data/init",
            df_class=TestCaseDataFrame,
        )
        log.success(f"loaded image pairs in test case '{self.data.name}' by batch")
