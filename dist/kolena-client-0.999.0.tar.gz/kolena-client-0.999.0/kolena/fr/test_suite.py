import dataclasses
import json
from collections import OrderedDict
from contextlib import contextmanager
from typing import Dict
from typing import Iterator
from typing import List
from typing import Optional

from pydantic.dataclasses import dataclass

from kolena._api.v1.fr import TestSuite as API
from kolena._utils import krequests
from kolena._utils import log
from kolena._utils.serde import from_dict
from kolena._utils.uninstantiable import Uninstantiable
from kolena._utils.validators import ValidatorConfig
from kolena.fr.test_case import TestCase


class TestSuite(Uninstantiable["TestSuite.Data"]):
    @dataclass(frozen=True, config=ValidatorConfig)
    class Data:
        id: int
        name: str
        version: int
        description: str
        baseline_test_cases: List[TestCase.Data]
        non_baseline_test_cases: List[TestCase.Data]
        baseline_image_count: int
        baseline_pair_count_genuine: int
        baseline_pair_count_imposter: int

    @classmethod
    def create(cls, name: str, description: Optional[str] = None) -> "TestSuite":
        """
        Create a new test suite with the provided name.

        :param name: unique name for the test suite being created
        :param description: optionally specify a free-form description of this test suite
        :returns: the newly created test suite, empty and with version 0
        :raises RemoteError: if the test suite could not be created, e.g. because a test suite with the provided name
            already exists
        """
        log.info(f"creating test suite '{name}'")
        request = API.CreateRequest(name=name, description=description or "")
        res = krequests.post(endpoint_path="/fr/test-suite/create", data=json.dumps(dataclasses.asdict(request)))
        krequests.raise_for_status(res)
        log.success(f"created test suite '{name}'")
        return TestSuite.__factory__(from_dict(data_class=TestSuite.Data, data=res.json()))

    @classmethod
    def load_by_name(cls, name: str, version: Optional[int] = None) -> "TestSuite":
        """
        Retrieve the existing test suite with the provided name.

        :param name: name of the test suite to retrieve
        :param version: optionally specify the version of the named test suite to retrieve. When absent the latest
            version of the test suite is returned
        :return: the retrieved test suite
        :raises RemoteError: if the test suite could not be loaded, e.g. if no test suite with the provided name exists
        """
        log.info(f"loading test suite '{name}'")
        request = API.LoadByNameRequest(name=name, version=version)
        res = krequests.put(endpoint_path="/fr/test-suite/load-by-name", data=json.dumps(dataclasses.asdict(request)))
        krequests.raise_for_status(res)
        log.success(f"loaded test suite '{name}'")
        return TestSuite.__factory__(from_dict(data_class=TestSuite.Data, data=res.json()))

    @dataclass(config=ValidatorConfig)
    class _Editor:
        edited: bool
        description: str
        baseline_test_cases: Dict[str, int]  # map from test case name -> id
        non_baseline_test_cases: Dict[str, int]

    class Editor(Uninstantiable[_Editor]):
        def description(self, description: str) -> None:
            """
            Update the description of the test suite.

            :param description: the new description of the test suite
            """
            self.data.edited = True
            self.data.description = description

        def add(self, test_case: TestCase, is_baseline: bool = False) -> None:
            """
            Add the provided :class:`kolena.fr.TestCase` to the test suite.

            :param test_case: the test case to add to the suite
            :param is_baseline: specify that this test case is a part of the "baseline," i.e. if the samples in this
                test case should contribute to the computation of thresholds within this test suite
            :raises ValueError: if this test case is already in this test suite, including other versions of the test
                case. Only a single version of a given test case may be included within a suite
            """
            name = test_case.data.name
            if name in self.data.baseline_test_cases.keys() or name in self.data.non_baseline_test_cases.keys():
                raise ValueError(f"test case '{name}' already in suite")
            self.data.edited = True
            if is_baseline:
                self.data.baseline_test_cases[name] = test_case.data.id
            else:
                self.data.non_baseline_test_cases[name] = test_case.data.id

        def remove(self, test_case: TestCase) -> None:
            """
            Remove the provided :class:`kolena.fr.TestCase` from the test suite. Any version of this test case in the
            suite will be removed; the version does not need to match exactly.

            :param test_case: the test case to be removed
            """
            name = test_case.data.name
            if name in self.data.baseline_test_cases.keys():
                self.data.baseline_test_cases.pop(name)
            elif name in self.data.non_baseline_test_cases.keys():
                self.data.non_baseline_test_cases.pop(name)
            else:
                raise KeyError(f"test case '{name}' not in suite")
            self.data.edited = True

        def merge(self, test_case: TestCase, is_baseline: Optional[bool] = None) -> None:
            """
            Add the :class:`kolena.fr.TestCase` to the suite. If a test case by this name already exists in the suite,
            replace the previous version of that test case with the newly provided version.

            :param test_case: the test case to be merged into the test suite
            :param is_baseline: optionally specify whether or not this test case should be considered as a part of the
                baseline for this test suite. When not specified, the previous value for ``is_baseline`` for this test
                case in this test suite is propagated forward. Defaults to false if the test case does not already exist
                in this suite.
            """
            name = test_case.data.name
            set_is_baseline: Optional[bool] = None
            if name in self.data.baseline_test_cases.keys():
                self.data.baseline_test_cases.pop(name)
                set_is_baseline = is_baseline if is_baseline is not None else True
            if name in self.data.non_baseline_test_cases.keys():
                self.data.non_baseline_test_cases.pop(name)
                set_is_baseline = is_baseline if is_baseline is not None else False
            self.add(test_case, is_baseline=set_is_baseline or False)

    @contextmanager
    def edit(self) -> Iterator[Editor]:
        """
        Context-managed way to perform many modification options on a test suite and commit the results when the context
        is exited, resulting in a single version bump.
        """
        editor = TestSuite.Editor.__factory__(
            TestSuite._Editor(
                edited=False,
                description=self.data.description,
                baseline_test_cases=OrderedDict(),
                non_baseline_test_cases=OrderedDict(),
            ),
        )
        for baseline_test_case in self.data.baseline_test_cases:
            editor.add(TestCase.__factory__(baseline_test_case), is_baseline=True)
        for non_baseline_test_case in self.data.non_baseline_test_cases:
            editor.add(TestCase.__factory__(non_baseline_test_case), is_baseline=False)
        editor.data.edited = False

        yield editor

        # no-op contexts have no effect, do not bump version
        if not editor.data.edited:
            return

        log.info(f"updating test suite '{self.data.name}'")
        request = API.EditRequest(
            test_suite_id=self.data.id,
            current_version=self.data.version,
            name=self.data.name,
            description=editor.data.description,
            baseline_test_case_ids=list(editor.data.baseline_test_cases.values()),
            non_baseline_test_case_ids=list(editor.data.non_baseline_test_cases.values()),
        )
        res = krequests.post(endpoint_path="/fr/test-suite/edit", data=json.dumps(dataclasses.asdict(request)))
        krequests.raise_for_status(res)
        test_suite_data = from_dict(data_class=TestSuite.Data, data=res.json())
        log.success(f"updated test suite '{self.data.name}'")
        self.__update__(test_suite_data)
