from typing import Type

from pydantic.dataclasses import dataclass

from kolena._utils.validators import ValidatorConfig
from kolena.workflow._datatypes import DataObject
from kolena.workflow._validators import validate_data_object_type


@dataclass(frozen=True, config=ValidatorConfig)
class Inference(DataObject):
    """
    The inference produced by a model.

    Typically the structure of this object closely mirrors the structure of the :class:`kolena.workflow.GroundTruth` for
    a workflow, but this is not a requirement.

    During evaluation, the :class:`kolena.workflow.TestSample` objects, ground truth objects, and these inference
    objects are provided to the :class:`kolena.workflow.Evaluator` implementation to compute metrics.

    This object may contain any combination of scalars (e.g. ``str``, ``float``),
    :class:`kolena.workflow.annotation.Annotation` objects, or lists of these objects.
    """


def _validate_inference_type(inference_type: Type[Inference]) -> None:
    if not issubclass(inference_type, Inference):
        raise ValueError(f"Inference must subclass {Inference.__name__}")

    validate_data_object_type(inference_type)
