from abc import ABCMeta
from typing import Dict
from typing import List
from typing import Tuple

from pydantic.dataclasses import dataclass

from kolena._utils.validators import ValidatorConfig
from kolena.workflow._datatypes import DataType
from kolena.workflow._datatypes import TypedDataObject


class _AnnotationType(DataType):
    BOUNDING_BOX = "BOUNDING_BOX"
    POLYGON = "POLYGON"
    POLYLINE = "POLYLINE"
    KEYPOINTS = "KEYPOINTS"
    BOUNDING_BOX_3D = "BOUNDING_BOX_3D"
    SEGMENTATION_MASK = "SEGMENTATION_MASK"
    BITMAP_MASK = "BITMAP_MASK"
    CLASSIFICATON_LABEL = "LABEL"

    @staticmethod
    def _data_category() -> str:
        return "ANNOTATION"


@dataclass(frozen=True, config=ValidatorConfig)
class Annotation(TypedDataObject[_AnnotationType], metaclass=ABCMeta):
    """
    Where applicable, annotations are visualized in the web platform.

    For example, when viewing images, any annotations present in a :class:`kolena.workflow.TestSample`,
    :class:`kolena.workflow.GroundTruth`, :class:`kolena.workflow.Inference`, or
    :class:`kolena.workflow.MetricsTestSample` are rendered on top of the image.
    """


@dataclass(frozen=True, config=ValidatorConfig)
class BoundingBox(Annotation):
    """Rectangular bounding box specified with pixel coordinates of the top left and bottom right vertices."""

    top_left: Tuple[float, float]
    bottom_right: Tuple[float, float]

    @staticmethod
    def _data_type() -> _AnnotationType:
        return _AnnotationType.BOUNDING_BOX


@dataclass(frozen=True, config=ValidatorConfig)
class LabeledBoundingBox(BoundingBox):
    """
    Rectangular bounding box specified with pixel coordinates of the top left and bottom right vertices and a string
    label.
    """

    label: str


@dataclass(frozen=True, config=ValidatorConfig)
class Polygon(Annotation):
    """Arbitrary polygon specified by three or more pixel coordinates."""

    points: List[Tuple[float, float]]

    @staticmethod
    def _data_type() -> _AnnotationType:
        return _AnnotationType.POLYGON

    def __post_init__(self) -> None:
        if len(self.points) < 3:
            raise ValueError(f"{type(self).__name__} must have at least three points ({len(self.points)} provided)")


@dataclass(frozen=True, config=ValidatorConfig)
class LabeledPolygon(Polygon):
    """Arbitrary polygon specified by three or more pixel coordinates and a string label."""

    label: str


@dataclass(frozen=True, config=ValidatorConfig)
class Keypoints(Annotation):
    """Array of any number of keypoints specified in pixel coordinates."""

    points: List[Tuple[float, float]]

    @staticmethod
    def _data_type() -> _AnnotationType:
        return _AnnotationType.KEYPOINTS


@dataclass(frozen=True, config=ValidatorConfig)
class Polyline(Annotation):
    """Polyline with any number of vertices specified in pixel coordinates."""

    points: List[Tuple[float, float]]

    @staticmethod
    def _data_type() -> _AnnotationType:
        return _AnnotationType.POLYLINE


@dataclass(frozen=True, config=ValidatorConfig)
class BoundingBox3D(Annotation):
    """
    Three-dimensional cuboid bounding box in a right-handed coordinate system.

    Specified by (x, y, z) coordinates for the ``center`` of the cuboid, (x, y, z) ``dimensions``, and a ``rotation``
    parameter specifying the degrees of rotation about each axis (x, y, z) ranging [-pi, pi].
    """

    #: (x, y, z) coordinates specifying the center of the bounding box.
    center: Tuple[float, float, float]

    #: (x, y, z) measurements specifying the dimensions of the bounding box.
    dimensions: Tuple[float, float, float]

    #: Rotations in degrees about each (x, y, z) axis.
    rotations: Tuple[float, float, float]

    @staticmethod
    def _data_type() -> _AnnotationType:
        return _AnnotationType.BOUNDING_BOX_3D


@dataclass(frozen=True, config=ValidatorConfig)
class LabeledBoundingBox3D(BoundingBox3D):
    """:class:`BoundingBox3D` with additional string label."""

    label: str


@dataclass(frozen=True, config=ValidatorConfig)
class SegmentationMask(Annotation):
    """
    Raster segmentation mask. The `locator` is the URL to the image file representing the mask data.

    The mask data is a two-dimensional ``np.uint8`` array where each element is the numerical label ID of its class, as
    specified in the `labels`` map.
    """

    #: Mapping of label ID to label value.
    labels: Dict[int, str]

    #: URL of the segmentation mask data.
    locator: str

    @staticmethod
    def _data_type() -> _AnnotationType:
        return _AnnotationType.SEGMENTATION_MASK


@dataclass(frozen=True, config=ValidatorConfig)
class BitmapMask(Annotation):
    """Arbitrary bitmap mask. The `locator` is the URL to the image file representing the mask."""

    #: URL of the bitmap data.
    locator: str

    @staticmethod
    def _data_type() -> _AnnotationType:
        return _AnnotationType.BITMAP_MASK


@dataclass(frozen=True, config=ValidatorConfig)
class ClassificationLabel(Annotation):
    """Label of classification."""

    label: str

    @staticmethod
    def _data_type() -> _AnnotationType:
        return _AnnotationType.CLASSIFICATON_LABEL


_ANNOTATION_TYPES = [
    BoundingBox,
    LabeledBoundingBox,
    Polygon,
    LabeledPolygon,
    Keypoints,
    Polyline,
    BoundingBox3D,
    LabeledBoundingBox3D,
    SegmentationMask,
    BitmapMask,
    ClassificationLabel,
]
