import dataclasses
import json
from abc import ABCMeta
from contextlib import contextmanager
from typing import Iterator
from typing import List
from typing import Optional
from typing import Type

from pydantic import validate_arguments

from kolena._api.v1.core import TestSuite as API
from kolena._utils import krequests
from kolena._utils import log
from kolena._utils.frozen import Frozen
from kolena._utils.instrumentation import telemetry
from kolena._utils.instrumentation import WithTelemetry
from kolena._utils.serde import from_dict
from kolena._utils.validators import ValidatorConfig
from kolena.errors import RemoteError
from kolena.workflow._validators import assert_workflows_match
from kolena.workflow.test_case import TestCase
from kolena.workflow.workflow import Workflow


class TestSuite(Frozen, WithTelemetry, metaclass=ABCMeta):
    """
    A test suite groups together one or more test cases.
    """

    _test_case_type: Type[TestCase]

    #: The :class:`kolena.workflow.Workflow` of this test suite.
    workflow: Workflow

    _id: int

    #: The unique name of this test suite. Cannot be changed after creation.
    name: str

    #: The version of this test suite. A test suite's version is automatically incremented whenever it is edited via
    #: :meth:`TestSuite.edit`.
    version: int

    #: Free-form, human-readable description of this test suite. Can be edited at any time via :meth:`TestSuite.edit`.
    description: str

    #: The :class:`kolena.workflow.TestCase` objects belonging to this test suite.
    test_cases: List[TestCase]

    @telemetry
    def __init_subclass__(cls) -> None:
        if not hasattr(cls, "workflow"):
            raise NotImplementedError(f"{cls.__name__} must implement class attribute 'workflow'")
        if not hasattr(cls, "_test_case_type"):
            raise NotImplementedError(f"{cls.__name__} must implement class attribute '_test_case_type'")
        super().__init_subclass__()

    @validate_arguments(config=ValidatorConfig)
    def __init__(
        self,
        name: str,
        version: Optional[int] = None,
        description: Optional[str] = None,
        test_cases: Optional[List[TestCase]] = None,
        reset: bool = False,
    ):
        if type(self) == TestSuite:
            raise Exception("<TestSuite> must be subclassed.")
        self._validate_test_cases(test_cases)

        try:
            self._populate_from_other(self.load(name, version))
            if description is not None and self.description != description and not reset:
                log.warn("test suite already exists, not updating description when reset=False")
            if test_cases is not None:
                if self.version > 0 and not reset:
                    log.warn("test suite already exists, not updating test cases when reset=False")
                else:
                    self._hydrate(test_cases, description)
        except RemoteError:  # TODO(gh): better exception?
            self._populate_from_other(self.create(name, description, test_cases))
        self._freeze()

    @classmethod
    def _validate_test_cases(cls, test_cases: Optional[List[TestCase]] = None) -> None:
        if test_cases:
            if any(cls.workflow != testcase.workflow for testcase in test_cases):
                raise TypeError("test case workflow does not match test suite's")

    def _populate_from_other(self, other: "TestSuite") -> None:
        with self._unfrozen():
            self._id = other._id
            self.name = other.name
            self.version = other.version
            self.description = other.description
            self.test_cases = other.test_cases

    @classmethod
    def _create_from_data(cls, data: API.EntityData) -> "TestSuite":
        assert_workflows_match(cls.workflow.name, data.workflow)
        obj = cls.__new__(cls)
        obj._id = data.id
        obj.name = data.name
        obj.version = data.version
        obj.description = data.description
        obj.test_cases = [cls._test_case_type._create_from_data(tc) for tc in data.test_cases]
        obj._freeze()
        return obj

    def _hydrate(self, test_cases: List[TestCase], description: Optional[str] = None) -> None:
        with self.edit(reset=True) as editor:
            if description is not None:
                editor.description(description)
            for test_case in test_cases:
                editor.add(test_case)

    @classmethod
    def create(
        cls,
        name: str,
        description: Optional[str] = None,
        test_cases: Optional[List[TestCase]] = None,
    ) -> "TestSuite":
        """
        Create a new test suite with the provided name.

        :param name: the name of the new test suite to create.
        :param description: optional free-form description of the test suite to create.
        :param test_cases: optionally specify a set of test cases to populate the test suite.
        :return: the newly created test suite.
        """
        log.info(f"creating test suite '{name}'")
        cls._validate_test_cases(test_cases)
        request = API.CreateRequest(name=name, description=description or "", workflow=cls.workflow.name)
        res = krequests.post(endpoint_path="/generic/test-suite/create", data=json.dumps(dataclasses.asdict(request)))
        krequests.raise_for_status(res)
        data = from_dict(data_class=API.EntityData, data=res.json())
        obj = cls._create_from_data(data)
        if test_cases is not None:
            obj._hydrate(test_cases)
        log.success(f"created test suite '{name}'")
        return obj

    @classmethod
    def load(cls, name: str, version: Optional[int] = None) -> "TestSuite":
        """
        Load an existing test suite with the provided name.

        :param name: the name of the test suite to load.
        :param version: optionally specify a particular version of the test suite to load. Defaults to the latest
            version when unset.
        :return: the loaded test suite.
        """
        request = API.LoadByNameRequest(name=name, version=version)
        res = krequests.put(endpoint_path="/generic/test-suite/load", data=json.dumps(dataclasses.asdict(request)))
        krequests.raise_for_status(res)
        data = from_dict(data_class=API.EntityData, data=res.json())
        return cls._create_from_data(data)

    class Editor:
        _test_cases: List[TestCase]
        _reset: bool
        _description: str
        _initial_test_case_ids: List[int]
        _initial_description: str

        @validate_arguments(config=ValidatorConfig)
        def __init__(self, test_cases: List[TestCase], description: str, reset: bool):
            self._test_cases = test_cases if not reset else []
            self._reset = reset
            self._description = description
            self._initial_test_case_ids = [tc._id for tc in test_cases]
            self._initial_description = description

        @validate_arguments(config=ValidatorConfig)
        def description(self, description: str) -> None:
            """Update the description of the test suite."""
            self._description = description

        @validate_arguments(config=ValidatorConfig)
        def add(self, test_case: TestCase) -> None:
            """
            Add a test case to this test suite. If a different version of the test case already exists in this test
            suite, it is replaced.

            :param test_case: the test case to add to the test suite.
            """
            self._test_cases = [*(tc for tc in self._test_cases if tc.name != test_case.name), test_case]

        @validate_arguments(config=ValidatorConfig)
        def remove(self, test_case: TestCase) -> None:
            """
            Remove a test case from this test suite. Does nothing if the test case is not in the test suite.

            :param test_case: the test case to remove.
            """
            self._test_cases = [tc for tc in self._test_cases if tc.name != test_case.name]

        def _edited(self) -> bool:
            test_case_ids = [tc._id for tc in self._test_cases]
            return self._description != self._initial_description or self._initial_test_case_ids != test_case_ids

    @contextmanager
    def edit(self, reset: bool = False) -> Iterator[Editor]:
        """
        Edit this test suite in a context:

        .. code-block:: python

            with test_suite.edit() as editor:
                # perform as many editing actions as desired
                editor.add(...)
                editor.remove(...)

        Changes are committed to the when the context is exited.

        :param reset: clear any and all test cases currently in the test suite.
        """
        editor = self.Editor(self.test_cases, self.description, reset)

        yield editor

        if not editor._edited():
            return

        log.info(f"updating test suite '{self.name}'")
        request = API.EditRequest(
            test_suite_id=self._id,
            current_version=self.version,
            name=self.name,
            description=editor._description,
            test_case_ids=[tc._id for tc in editor._test_cases],
        )
        res = krequests.post(endpoint_path="/generic/test-suite/edit", data=json.dumps(dataclasses.asdict(request)))
        krequests.raise_for_status(res)
        test_suite_data = from_dict(data_class=API.EntityData, data=res.json())
        self._populate_from_other(self._create_from_data(test_suite_data))
        log.success(f"updated test suite '{self.name}'")
