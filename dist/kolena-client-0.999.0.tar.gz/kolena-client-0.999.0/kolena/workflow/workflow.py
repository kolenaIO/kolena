from typing import Type

from pydantic.dataclasses import dataclass

from kolena.workflow import GroundTruth
from kolena.workflow import Inference
from kolena.workflow import TestSample
from kolena.workflow.ground_truth import _validate_ground_truth_type
from kolena.workflow.inference import _validate_inference_type
from kolena.workflow.test_sample import _validate_test_sample_type


_RESERVED_WORKFLOW_NAMES = {"fr", "classification", "detection", "keypoints"}


@dataclass(frozen=True)
class Workflow:
    """
    The definition of a workflow and its associated types.
    """

    #: The name of the workflow. Should be unique, meaningful, and human-readable.
    name: str

    #: The :class:`kolena.workflow.TestSample` type for the workflow, using one of the builtin test sample types
    #: (e.g. :class:`kolena.workflow.Image`) and extending as necessary with additional fields.
    test_sample_type: Type[TestSample]

    #: The custom :class:`kolena.workflow.GroundTruth` type for the workflow.
    ground_truth_type: Type[GroundTruth]

    #: The custom :class:`kolena.workflow.Inference` type for the workflow.
    inference_type: Type[Inference]

    def __post_init__(self) -> None:
        object.__setattr__(self, "name", self.name.strip())
        if self.name == "":
            raise ValueError("invalid zero-length name provided")
        if self.name.lower() in _RESERVED_WORKFLOW_NAMES:
            raise ValueError(f"invalid reserved name '{self.name}' provided")

        _validate_test_sample_type(self.test_sample_type)
        _validate_ground_truth_type(self.test_sample_type, self.ground_truth_type)
        _validate_inference_type(self.inference_type)
