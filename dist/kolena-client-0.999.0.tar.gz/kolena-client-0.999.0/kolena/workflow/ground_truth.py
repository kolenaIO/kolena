import copy
from typing import Type

from pydantic.dataclasses import dataclass

from kolena._utils.validators import ValidatorConfig
from kolena.workflow import ImagePair
from kolena.workflow import TestSample
from kolena.workflow._datatypes import DataObject
from kolena.workflow._validators import validate_field


@dataclass(frozen=True, config=ValidatorConfig)
class GroundTruth(DataObject):
    """
    The ground truth against which a model is evaluated.

    A test case contains one or more :class:`kolena.workflow.TestSample` objects each paired with a ground truth object.
    During evaluation, these test samples, ground truths, and your model's inferences are provided to the
    :class:`kolena.workflow.Evaluator` implementation.

    This object may contain any combination of scalars (e.g. ``str``, ``float``),
    :class:`kolena.workflow.annotation.Annotation` objects, or lists of these objects.
    """


def _validate_ground_truth_type(
    test_sample_type: Type[TestSample],
    ground_truth_type: Type[GroundTruth],
    recurse: bool = True,
) -> None:
    if not issubclass(ground_truth_type, GroundTruth):
        raise ValueError(f"Ground truth must subclass {GroundTruth.__name__}")

    fields_by_name = copy.copy(getattr(ground_truth_type, "__annotations__", {}))

    # for now, this is the only class that requires some additional validation, as it has additional structure
    if recurse and issubclass(test_sample_type, ImagePair):
        # special "a" and "b" fields corresponding to overlays for "locator_a" and "locator_b" images
        for subtype in ["a", "b"]:
            ground_truth_subtype = fields_by_name.get(subtype, None)
            if ground_truth_subtype is not None:
                _validate_ground_truth_type(test_sample_type, ground_truth_subtype, recurse=False)
                fields_by_name.pop(subtype)

    for field_name, field_value in fields_by_name.items():  # validate only non-special (nested) fields
        validate_field(field_name, field_value)
