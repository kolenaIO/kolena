import copy
from abc import ABCMeta
from typing import Any
from typing import Dict
from typing import List
from typing import Type
from typing import Union

from pydantic import StrictBool
from pydantic import StrictFloat
from pydantic import StrictInt
from pydantic import StrictStr
from pydantic.dataclasses import dataclass

from kolena._utils.validators import ValidatorConfig
from kolena.workflow._datatypes import DataType
from kolena.workflow._datatypes import TypedDataObject
from kolena.workflow._validators import validate_field
from kolena.workflow._validators import validate_metadata_dict


#: Type of the ``metadata`` field that can be included on :class:`kolena.workflow.TestSample` definitions. String
#: (``str``) keys and scalar values (``int``, ``float``, ``str``, ``bool``, ``None``) as well as scalar list values are
#: permitted.
Metadata = Dict[
    str,
    Union[
        None,
        # prevent coercion of values in metadata -- see: https://pydantic-docs.helpmanual.io/usage/types/#strict-types
        StrictStr,
        StrictFloat,
        StrictInt,
        StrictBool,
        # Pydantic's StrictX doesn't play nicely with deserialization (e.g. isinstance("a string", StrictStr) => False)
        #  -- include base scalar types as fallbacks for this purpose
        str,
        float,
        int,
        bool,
        List[
            Union[
                None,
                StrictStr,
                StrictFloat,
                StrictInt,
                StrictBool,
                str,
                float,
                int,
                bool,
            ]
        ],
    ],
]
_METADATA_KEY = "metadata"


class _TestSampleType(DataType):
    IMAGE = "IMAGE"
    IMAGE_PAIR = "IMAGE_PAIR"
    IMAGE_TEXT = "IMAGE_TEXT"
    TEXT = "TEXT"
    VIDEO = "VIDEO"
    CUSTOM = "CUSTOM"

    @staticmethod
    def _data_category() -> str:
        return "TEST_SAMPLE"


@dataclass(frozen=True, config=ValidatorConfig)
class TestSample(TypedDataObject[_TestSampleType], metaclass=ABCMeta):
    """
    The inputs to a model.

    Test samples can be customized as necessary for a workflow by extending this class or one of the built-in test
    sample types.

    Extensions to the ``TestSample`` class may define a ``metadata`` field of type
    :data:`kolena.workflow.test_sample.Metadata` containing a dictionary of scalar properties associated with the test
    sample, intended for use when sorting or filtering test samples.

    Kolena handles the ``metadata`` field differently from other test sample fields. Updates to the ``metadata`` object
    for a given test sample are merged with previously uploaded metadata. As such, ``metadata`` for a given test sample
    within a test case is **not** immutable, and should **not** be relied on when an implementation of
    :class:`kolena.workflow.Model` computes inferences, or when an implementation of :class:`kolena.workflow.Evaluator`
    evaluates metrics.
    """

    @staticmethod
    def _data_type() -> _TestSampleType:
        return _TestSampleType.CUSTOM

    def _to_dict(self) -> Dict[str, Any]:
        base_dict = super()._to_dict()
        base_dict.pop(_METADATA_KEY, None)
        return base_dict

    def _to_metadata_dict(self) -> Metadata:
        base_dict = super()._to_dict()
        return base_dict.pop(_METADATA_KEY, {})


@dataclass(frozen=True, config=ValidatorConfig)
class Image(TestSample):
    """An image located in a cloud bucket or served at a URL."""

    locator: str

    @classmethod
    def _data_type(cls) -> _TestSampleType:
        return _TestSampleType.IMAGE


@dataclass(frozen=True, config=ValidatorConfig)
class ImagePair(TestSample):
    """Two images."""

    a: Image
    b: Image

    @classmethod
    def _data_type(cls) -> _TestSampleType:
        return _TestSampleType.IMAGE_PAIR


@dataclass(frozen=True, config=ValidatorConfig)
class Text(TestSample):
    """A text snippet."""

    text: str

    @classmethod
    def _data_type(cls) -> _TestSampleType:
        return _TestSampleType.TEXT


@dataclass(frozen=True, config=ValidatorConfig)
class ImageText(Image, Text):
    """An image paired with a text snippet."""

    @classmethod
    def _data_type(cls) -> _TestSampleType:
        return _TestSampleType.IMAGE_TEXT


@dataclass(frozen=True, config=ValidatorConfig)
class Video(TestSample):
    """A video clip located in a cloud bucket or served at a URL."""

    locator: str  # TODO(gh): also require a thumbnail? or can we be clever and fetch on the fly?

    @classmethod
    def _data_type(cls) -> _TestSampleType:
        return _TestSampleType.VIDEO


_TEST_SAMPLE_BASE_TYPES = [Image, ImagePair, ImageText, Text, Video]


def _validate_test_sample_type(test_sample_type: Type[TestSample], recurse: bool = True) -> None:
    if not issubclass(test_sample_type, TestSample):
        raise ValueError(f"Test sample must subclass {TestSample.__name__}")

    if (
        not issubclass(test_sample_type, tuple(_TEST_SAMPLE_BASE_TYPES))
        and test_sample_type._data_type() is not _TestSampleType.CUSTOM
    ):
        supported_bases = ", ".join(t.__name__ for t in _TEST_SAMPLE_BASE_TYPES)
        raise ValueError(
            f"Test sample not extending a supported base must declare data_type {_TestSampleType.CUSTOM.value}.\n"
            f"Supported bases: {supported_bases}",
        )

    # TODO: this is structurally identical to implementation in validate_ground_truth_type and
    #  validate_metrics_test_sample_type -- share?
    fields_by_name = copy.copy(getattr(test_sample_type, "__annotations__", {}))
    if recurse and issubclass(test_sample_type, ImagePair):
        for subtype in ["a", "b"]:
            test_sample_subtype = fields_by_name.get(subtype, None)
            if test_sample_subtype is not None:
                _validate_test_sample_type(test_sample_subtype, recurse=False)
                fields_by_name.pop(subtype)

    for field_name, field_value in fields_by_name.items():  # validate only non-special (nested) fields
        if field_name == "metadata":
            validate_metadata_dict(field_value)
        else:
            validate_field(field_name, field_value)
