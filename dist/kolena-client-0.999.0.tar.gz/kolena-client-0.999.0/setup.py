# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['kolena',
 'kolena._api',
 'kolena._api.v1',
 'kolena._utils',
 'kolena._utils.dataframes',
 'kolena.classification',
 'kolena.detection',
 'kolena.detection._internal',
 'kolena.fr',
 'kolena.workflow']

package_data = \
{'': ['*']}

install_requires = \
['Pillow>=9.1.1,<10.0.0',
 'Shapely>=1.8.5,<2.0.0',
 'dacite>=1.6',
 'deprecation>=2.1.0,<3.0.0',
 'numpy>=1.19',
 'pandas>=1.1,<1.4',
 'pandera>=0.9.0',
 'pyarrow>=8',
 'pydantic>=1.8',
 'requests-toolbelt>=0.9.1,<0.10.0',
 'requests>=2.20',
 'retrying>=1.3.3,<2.0.0',
 'termcolor>=1.1.0,<2.0.0',
 'tqdm>=4,<5']

extras_require = \
{':python_version < "3.8"': ['importlib-metadata<5.0']}

setup_kwargs = {
    'name': 'kolena-client',
    'version': '0.999.0',
    'description': "Client for Kolena's machine learning (ML) testing and debugging platform.",
    'long_description': "# Kolena Client\n\n`kolena-client` is the Python client library for interacting with [Kolena](https://www.kolena.io/)'s\nmachine learning (ML) testing and debugging platform.\n",
    'author': 'Kolena Engineering',
    'author_email': 'eng@kolena.io',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://kolena.io',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.7,<3.11',
}


setup(**setup_kwargs)
